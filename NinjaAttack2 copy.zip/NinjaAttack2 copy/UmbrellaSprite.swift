import SpriteKit

public class UmbrellaSprite : SKSpriteNode {
    private var destination : CGPoint!
    private let easing : CGFloat = 0.1
    public var isTouched = false
    public var trashType : Int = 0
    
    public static func newInstance() -> UmbrellaSprite {
        let umbrella = UmbrellaSprite(imageNamed: "umbrella")
      
        
        let path = UIBezierPath()
        path.move(to: CGPoint())
        path.addLine(to: CGPoint(x: -umbrella.size.width / 2 - 30, y: 100))
        path.addLine(to: CGPoint(x: 0, y: umbrella.size.height / 2))
        path.addLine(to: CGPoint(x: umbrella.size.width / 2 + 30, y: 100))
        
        umbrella.physicsBody = SKPhysicsBody(polygonFrom: path.cgPath)
        umbrella.physicsBody?.isDynamic = false
        umbrella.physicsBody?.restitution = 0.9
        
        return umbrella
        
        
    }
    
    public func updatePosition(point : CGPoint) {
        position = point
        destination = point
    }
    
    public func setDestination(destination : CGPoint) {
        self.destination = destination
    }
    
    public func update(deltaTime : TimeInterval) {
        
        if isTouched == true {
        let distance = sqrt(pow((destination.x - position.x), 2) + pow((destination.y - position.y), 2))
        
        if(distance > 1) {
            let directionX = (destination.x - position.x)
            let directionY = (destination.y - position.y)
            
            position.x += directionX * easing
            position.y += directionY * easing
        } else {
            position = destination;
        }
            
    }
    }
    
    func checkTouch (touchPoint: CGPoint) {
        if (abs(self.position.x-(touchPoint.x)) <= self.size.width/2) && (abs(self.position.y-(touchPoint.y)) <= self.size.height/2) {
    self.isTouched = true
    self.removeAllActions()
        
    }
      
      
    }
}



