import SpriteKit


class GameScene: SKScene {
  var viewController:UIViewController?
  
  let water = SKSpriteNode(imageNamed: "water")
  let trash = SKSpriteNode(imageNamed: "trashh")
  let compost = SKSpriteNode(imageNamed: "compp")
  let recycle = SKSpriteNode(imageNamed: "recc")
  var x1 = SKSpriteNode(imageNamed: "xempty")
  var x2 = SKSpriteNode(imageNamed: "xempty")
  var x3 = SKSpriteNode(imageNamed: "xempty")
  let conveyer = SKSpriteNode(imageNamed: "conveyer")
  let playAgain = SKSpriteNode(imageNamed: "pa")
  let gameOver = SKSpriteNode(imageNamed: "go")
  
  var numberWrong = 0
  var speedMonster: Double = 6
  
  //
  func returnToMainMenu() {
    self.viewController?.performSegue(withIdentifier: "push", sender: viewController)
    print("gamescene")
  }
  //
  
  
  struct PhysicsCategory {
    static let none      : UInt32 = 0
    static let all       : UInt32 = UInt32.max
    static let monster   : UInt32 = 0b1       // 1
    static let trash:     UInt32 = 0b10      // 2
    static let recycle:     UInt32 = 0b100      // 2
    static let compost:     UInt32 = 0b1000      // 2
    static let water:     UInt32 = 0b10000      // 2

    
  }
  
  var trashnames = ["com1", "com2", "com3", "com4", "rec1", "rec2", "rec3", "rec 4", "trash1", "trash2", "trash3", "trash4"]
  
  var numberofmonsters: Int = 0
  
  // 1
  
  override func didMove(to view: SKView) {
    // 2
    backgroundColor = SKColor.white
    // 3
    // 4
    
    water.position = CGPoint(x: size.width/2, y: size.height/15)
    water.setScale(0.5)
    addChild(water)
    
    trash.position = CGPoint(x: size.width/6, y: size.height*13/16)
    trash.setScale(0.27)
    addChild(trash)
    
    recycle.position = CGPoint(x: size.width*9/24, y: size.height*13/16)
    recycle.setScale(0.21)
    addChild(recycle)
    
    conveyer.position = CGPoint(x: size.width/3, y: size.height*5/12)
    conveyer.setScale(0.5)
    addChild(conveyer)
    
    compost.position = CGPoint(x: size.width*7/12, y: size.height*13/16)
    compost.setScale(0.42)
    addChild(compost)
    
    playAgain.position = CGPoint(x: size.width/2, y: size.height/2-80)
    playAgain.setScale(0.6)
    addChild(playAgain)
    
    gameOver.position = CGPoint(x: size.width/2, y: size.height/2+70)
    gameOver.setScale(1)
    addChild(gameOver)
    
    x1.position = CGPoint(x: size.width-50, y: size.height-50)
    x1.setScale(0.2)
    addChild(x1)
    
    x2.position = CGPoint(x: size.width-100, y: size.height-50)
    x2.setScale(0.2)
    addChild(x2)
    
    x3.position = CGPoint(x: size.width-150, y: size.height-50)
    x3.setScale(0.2)
    addChild(x3)
    
    physicsWorld.gravity = .zero
    physicsWorld.contactDelegate = self
    
    run(SKAction.repeatForever(
      SKAction.sequence([
        SKAction.run(addMonster),
        SKAction.wait(forDuration: 2.0)
        ])
    ))
  }
  
  
  func random() -> CGFloat {
    return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
  }
  
  func random(min: CGFloat, max: CGFloat) -> CGFloat {
    return random() * (max - min) + min
  }
  
  func addMonster() {
    
    if numberWrong < 3 {
    
      playAgain.isHidden = true
      gameOver.isHidden = true
      
      
    // Create sprite
    let randomNumber = Int(arc4random_uniform(12))
    let monster = UmbrellaSprite(imageNamed: trashnames[randomNumber])
    
    monster.trashType = randomNumber
      
    monster.physicsBody = SKPhysicsBody(rectangleOf: monster.size) // 1
    monster.physicsBody?.isDynamic = true // 2
    monster.physicsBody?.categoryBitMask = PhysicsCategory.monster // 3
    monster.physicsBody?.contactTestBitMask = PhysicsCategory.trash // 4
    monster.physicsBody?.contactTestBitMask = PhysicsCategory.recycle // 4
    monster.physicsBody?.contactTestBitMask = PhysicsCategory.water // 4
    monster.physicsBody?.contactTestBitMask = PhysicsCategory.compost // 4
    monster.physicsBody?.collisionBitMask = PhysicsCategory.none // 5
    
    
    let size = CGSize(width: 80, height: 80)
    monster.scale(to: size)
    
    
    // Determine where to spawn the monster along the Y axis
    let actualY = size.height/2+150
    
    // Position the monster slightly off-screen along the right edge,
    // and along a random position along the Y axis as calculated above
    monster.position = CGPoint(x: 0 - monster.size.width/2, y: actualY)
    
    // Add the monster to the scene
    addChild(monster)
    
    // Determine speed of the monster
    let actualDuration = speedMonster
    let finalDuration = random(min: CGFloat(0.2), max: CGFloat(0.2))
    
    // Create the actions
    let actionMove = SKAction.move(to: CGPoint(x: size.width/2 + 400, y: actualY), duration: TimeInterval(actualDuration))
    let actionMove2 = SKAction.move(to: CGPoint(x: size.width/2 + 400, y: 0), duration: TimeInterval(finalDuration))
    
//    add numberWrong = numberWrong+1
//
    let actionMoveDone = SKAction.removeFromParent()
    monster.run(SKAction.sequence([actionMove, actionMove2, actionMoveDone]))
    
    
    numberofmonsters = numberofmonsters+1
      
    }
  }

  
  
  
  private var lastUpdateTime : TimeInterval = 0
  private var currentRainDropSpawnTime : TimeInterval = 0
  private var rainDropSpawnRate : TimeInterval = 0.5
  
  
  
  private let backgroundNode = BackgroundNode()
  
  override func sceneDidLoad() {
    self.lastUpdateTime = 0
    
    playAgain.name = "playAgain"
  }
  
  
  override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    
    
    for child1 in self.children {
      if let child = child1 as? UmbrellaSprite {
        
        let touchPoint = touches.first?.location(in: self)
        child.checkTouch(touchPoint:touchPoint!)
        if let point = touchPoint {
          child.setDestination(destination: point)
        }
      }
      if let child = child1 as? SKSpriteNode {
        if child.name == "playAgain" && child.isHidden == false {
          numberWrong = 0
          x1.texture = SKTexture(imageNamed: "xempty")
          x2.texture = SKTexture(imageNamed: "xempty")
          x3.texture = SKTexture(imageNamed: "xempty")
          for child1 in self.children {
            if let child = child1 as? UmbrellaSprite {
              child.isHidden = false
            }
            if let child = child1 as? SKSpriteNode {
              child.isHidden = false
              
            }
          }
          
          playAgain.isHidden = true
          gameOver.isHidden = true
          
          
        }
        
          
        }
      }
      
    }

  
  
  
  
  override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    
    
    
    for child1 in self.children {
      if let child = child1 as? UmbrellaSprite {
        
        let touchPoint = touches.first?.location(in: self)
        if let point = touchPoint {
          child.setDestination(destination: point)
        }
      }
    }
  }
  
  
  
  
  override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
    
    for child1 in self.children {
      if let child = child1 as? UmbrellaSprite {
        
        child.isTouched = false
        
      }
    }
    
    trash.physicsBody = SKPhysicsBody(circleOfRadius: trash.size.width*1/8)
    trash.physicsBody?.isDynamic = true
    trash.physicsBody?.categoryBitMask = PhysicsCategory.trash
    trash.physicsBody?.contactTestBitMask = PhysicsCategory.monster
    trash.physicsBody?.collisionBitMask = PhysicsCategory.none
    trash.physicsBody?.usesPreciseCollisionDetection = true
    
    
    recycle.physicsBody = SKPhysicsBody(circleOfRadius: recycle.size.width*1/8)
    recycle.physicsBody?.isDynamic = true
    recycle.physicsBody?.categoryBitMask = PhysicsCategory.recycle
    recycle.physicsBody?.contactTestBitMask = PhysicsCategory.monster
    recycle.physicsBody?.collisionBitMask = PhysicsCategory.none
    recycle.physicsBody?.usesPreciseCollisionDetection = true
    
    
    compost.physicsBody = SKPhysicsBody(circleOfRadius: compost.size.width*1/8)
    compost.physicsBody?.isDynamic = true
    compost.physicsBody?.categoryBitMask = PhysicsCategory.compost
    compost.physicsBody?.contactTestBitMask = PhysicsCategory.monster
    compost.physicsBody?.collisionBitMask = PhysicsCategory.none
    compost.physicsBody?.usesPreciseCollisionDetection = true
    
    water.physicsBody = SKPhysicsBody(rectangleOf: water.size)
    water.physicsBody?.isDynamic = true
    water.physicsBody?.categoryBitMask = PhysicsCategory.water
    water.physicsBody?.contactTestBitMask = PhysicsCategory.monster
    water.physicsBody?.collisionBitMask = PhysicsCategory.none
    water.physicsBody?.usesPreciseCollisionDetection = true
  }
  
  
  override func update(_ currentTime: TimeInterval) {
    // Called before each frame is rendered
    
    // Initialize _lastUpdateTime if it has not already been
    if (self.lastUpdateTime == 0) {
      self.lastUpdateTime = currentTime
      
      
    }
    
    // Calculate time since last update
    let dt = currentTime - self.lastUpdateTime
    
    // Update the Spawn Timer
    currentRainDropSpawnTime += dt
    
    
    self.lastUpdateTime = currentTime
    
    
    for child1 in self.children {
      if let child = child1 as? UmbrellaSprite {
        child.update(deltaTime: dt)
      }
      
    }
    
  }
  

  
  func trashDidCollideWithMonster(trash: SKSpriteNode, monster: UmbrellaSprite) {
      if 7 < monster.trashType && monster.trashType < 12 {
        monster.removeFromParent()
        if speedMonster > 1 {
          speedMonster = speedMonster-0.25
        }
      } else {
        numberWrong = numberWrong+1
        monster.removeFromParent()
        if numberWrong == 1 {
          x3.texture = SKTexture(imageNamed: "xfull")
        }
        
        if numberWrong == 2 {
          x2.texture = SKTexture(imageNamed: "xfull")
        }
        
        if numberWrong == 3 {
          x1.texture = SKTexture(imageNamed: "xfull")
        print("hide")
          
          for child1 in self.children {
            if let child = child1 as? UmbrellaSprite {
              child.isHidden = true
              }
            if let child = child1 as? SKSpriteNode {
              child.isHidden = true
              
            }
            }
          
            playAgain.isHidden = false
            gameOver.isHidden = false
          }
          
          //self.performSegue(withIdentifier identifier: "signInView",
                            //sender: Any?)
        
      }
    
  }
  
  func recycleDidCollideWithMonster(recycle: SKSpriteNode, monster: UmbrellaSprite) {
    if 3 < monster.trashType && monster.trashType < 8 {
      monster.removeFromParent()
      if speedMonster > 1 {
        speedMonster = speedMonster-0.25
      }
    } else {
      numberWrong = numberWrong+1
      monster.removeFromParent()
      if numberWrong == 1 {
        x3.texture = SKTexture(imageNamed: "xfull")
      }
      
      if numberWrong == 2 {
        x2.texture = SKTexture(imageNamed: "xfull")
      }
      
      if numberWrong == 3 {
        x1.texture = SKTexture(imageNamed: "xfull")
        print("hide")
        
        for child1 in self.children {
          if let child = child1 as? UmbrellaSprite {
            child.isHidden = true
          }
          if let child = child1 as? SKSpriteNode {
            child.isHidden = true
            
          }
        }
        
        playAgain.isHidden = false
        gameOver.isHidden = false
      }
      
    }
}
  
  func compostDidCollideWithMonster(compost: SKSpriteNode, monster: UmbrellaSprite) {
    if -1 < monster.trashType && monster.trashType < 4 {
      monster.removeFromParent()
      if speedMonster > 1 {
      speedMonster = speedMonster-0.25
      }
      
    } else {
      numberWrong = numberWrong+1
      monster.removeFromParent()
      if numberWrong == 1 {
        x3.texture = SKTexture(imageNamed: "xfull")
      }
      
      if numberWrong == 2 {
        x2.texture = SKTexture(imageNamed: "xfull")
      }
      
      if numberWrong == 3 {
        x1.texture = SKTexture(imageNamed: "xfull")
        print("hide")
        
        for child1 in self.children {
          if let child = child1 as? UmbrellaSprite {
            child.isHidden = true
          }
          if let child = child1 as? SKSpriteNode {
            child.isHidden = true
            
          }
        }
        
        playAgain.isHidden = false
        gameOver.isHidden = false
      }
      
    }
  

    }
  
  
  func waterDidCollideWithMonster(water: SKSpriteNode, monster: UmbrellaSprite) {
      numberWrong = numberWrong+1
      monster.removeFromParent()
    print ("hello")
    if numberWrong == 1 {
        x3.texture = SKTexture(imageNamed: "xfull")
      }
      
      if numberWrong == 2 {
        x2.texture = SKTexture(imageNamed: "xfull")
      }
      
      if numberWrong == 3 {
        x1.texture = SKTexture(imageNamed: "xfull")
        print("hide")
        
        for child1 in self.children {
          if let child = child1 as? UmbrellaSprite {
            child.isHidden = true
          }
          if let child = child1 as? SKSpriteNode {
            child.isHidden = true
            
          }
        }
        
        playAgain.isHidden = false
        gameOver.isHidden = false
    }
      
    }
  }



  extension GameScene: SKPhysicsContactDelegate {
    func didBegin(_ contact: SKPhysicsContact) {
      // 1
      var firstBody: SKPhysicsBody
      var secondBody: SKPhysicsBody
      if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
        firstBody = contact.bodyA
        secondBody = contact.bodyB
      } else {
        firstBody = contact.bodyB
        secondBody = contact.bodyA
      }

          if ((firstBody.categoryBitMask & PhysicsCategory.monster != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.trash != 0)) {
            if let monster = firstBody.node as? UmbrellaSprite,
              let trash = secondBody.node as? SKSpriteNode {
              trashDidCollideWithMonster(trash: trash, monster: monster)
            }
            
          }
      
      if ((firstBody.categoryBitMask & PhysicsCategory.monster != 0) &&
        (secondBody.categoryBitMask & PhysicsCategory.recycle != 0)) {
        if let monster = firstBody.node as? UmbrellaSprite,
          let recycle = secondBody.node as? SKSpriteNode {
          recycleDidCollideWithMonster(recycle: recycle, monster: monster)
        }
        
      }
      
      if ((firstBody.categoryBitMask & PhysicsCategory.monster != 0) &&
        (secondBody.categoryBitMask & PhysicsCategory.compost != 0)) {
        if let monster = firstBody.node as? UmbrellaSprite,
          let compost = secondBody.node as? SKSpriteNode {
          compostDidCollideWithMonster(compost: compost, monster: monster)
        }
        
      }
      if ((firstBody.categoryBitMask & PhysicsCategory.monster != 0) &&
        (secondBody.categoryBitMask & PhysicsCategory.water != 0)) {
        if let monster = firstBody.node as? UmbrellaSprite,
          let water = secondBody.node as? SKSpriteNode {
          waterDidCollideWithMonster(water: water, monster: monster)
        }
        
      }
    }
    
}


